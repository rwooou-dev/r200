(() => {
  const btn = document.querySelector('.menu-btn'), nav = document.querySelector('nav');
  btn.addEventListener('click', () => { const o = nav.classList.toggle('open'); btn.setAttribute('aria-expanded', o); });
  nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

  const tabs = document.querySelectorAll('.svc-tab'), panels = document.querySelectorAll('.svc-panel');
  tabs.forEach(t => t.addEventListener('click', () => {
    tabs.forEach(x => { x.classList.toggle('on', x === t); x.setAttribute('aria-selected', x === t); });
    panels.forEach(p => p.classList.toggle('on', p.dataset.i === t.dataset.i));
  }));

  const toast = document.querySelector('.toast');
  document.querySelectorAll('[data-copy]').forEach(b => b.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(b.dataset.copy); } catch (e) {
      const t = document.createElement('textarea'); t.value = b.dataset.copy; document.body.appendChild(t); t.select();
      try { document.execCommand('copy'); } catch (_) {} t.remove();
    }
    b.classList.add('ok'); toast.textContent = toast.dataset.ok + ' — ' + b.dataset.copy; toast.classList.add('show');
    setTimeout(() => { b.classList.remove('ok'); toast.classList.remove('show'); }, 1800);
  }));

  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));
  document.getElementById('yr').textContent = new Date().getFullYear();
})();
