"""Generates index.html (Arabic), en/index.html (English) and assets/tokens.css from site.config.json.
Run: python3 build.py"""
import os, json
ROOT = os.path.dirname(os.path.abspath(__file__))
CFG = json.load(open(os.path.join(ROOT, "site.config.json"), encoding="utf-8"))
DOMAIN = CFG["domain"]
CO = CFG["company"]
CT = CFG["contact"]
PHONE, PHONE_INTL, WA_INTL = CT["phone"], CT["phone_intl"], CT["whatsapp_intl"]
EMAIL, CR = CT["email"], CT["cr"]

def write_tokens():
    lines = ["/* GENERATED from site.config.json — do not edit by hand. */", ":root{"]
    for k, v in CFG["colors"].items():
        lines.append(f"  --c-{k}:{v['hex']}; /* {v['role']} */")
    lines.append("}")
    open(os.path.join(ROOT, "assets", "tokens.css"), "w", encoding="utf-8").write("\n".join(lines) + "\n")

def logo(gid, cls=""):
    return f'''<svg class="{cls}" viewBox="0 0 120 120" aria-hidden="true"><defs><linearGradient id="{gid}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#C9A574"/><stop offset=".55" stop-color="#A67C4E"/><stop offset="1" stop-color="#6B4A2B"/></linearGradient></defs><rect x="2" y="2" width="116" height="116" rx="26" fill="none" stroke="url(#{gid})" stroke-width="2.5"/><path d="M30 80V52L48 44V80Z" fill="url(#{gid})"/><path d="M54 80V20L76 32V80Z" fill="none" stroke="url(#{gid})" stroke-width="3" stroke-linejoin="round"/><line x1="65" y1="26" x2="65" y2="80" stroke="url(#{gid})" stroke-width="2"/><path d="M82 80V56L92 60V80Z" fill="url(#{gid})"/><line x1="34" y1="58" x2="44" y2="54" stroke="#C9A574" stroke-width="2" stroke-linecap="round"/><line x1="34" y1="66" x2="44" y2="63" stroke="#C9A574" stroke-width="2" stroke-linecap="round"/><line x1="34" y1="74" x2="44" y2="72" stroke="#C9A574" stroke-width="2" stroke-linecap="round"/><line x1="24" y1="85" x2="96" y2="85" stroke="url(#{gid})" stroke-width="2.6" stroke-linecap="round"/><path d="M28 95 q6 -5 12 0 t12 0 t12 0 t12 0 t12 0 t12 0" fill="none" stroke="url(#{gid})" stroke-width="2.4" stroke-linecap="round"/><path d="M40 104 q5 -4 10 0 t10 0 t10 0 t10 0" fill="none" stroke="#C9A574" stroke-width="2" stroke-linecap="round"/></svg>'''

WA = '<svg viewBox="0 0 24 24"><path d="M17.5 14.4c-.3-.1-1.8-.9-2-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.2-.2.2-.3.2-.6.1-.3-.1-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.4-.5c.2-.2.2-.3.3-.5.1-.2 0-.4 0-.5l-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.2 5.1 4.5.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.8-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.1-.3-.2-.6-.3zM12 21.8c-1.8 0-3.5-.5-5-1.4l-.4-.2-3.7 1 1-3.6-.2-.4C2.7 15.6 2.2 13.8 2.2 12 2.2 6.6 6.6 2.2 12 2.2S21.8 6.6 21.8 12 17.4 21.8 12 21.8zM12 .5C5.7.5.5 5.7.5 12c0 2 .5 4 1.5 5.7L.4 23.5l5.9-1.5c1.7.9 3.6 1.4 5.6 1.4 6.3 0 11.5-5.2 11.5-11.5S18.3.5 12 .5z"/></svg>'
MENU = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>'

AR = dict(
    lang="ar", dir="rtl", path="/", other="/en/", other_label="EN",
    title="ساحل البحر الأحمر للمقاولات العامة | من الهدم حتى التسليم",
    desc="شركة سعودية للمقاولات العامة في الرياض والمدينة المنورة: هدم، حفر، إنشاءات عظم، وتشطيبات نهائية بعقد واحد. خبرة منذ 1436هـ.",
    name=CO["name_ar"], sub=CO["sub_ar"],
    nav=[("#about", "من نحن"), ("#services", "خدماتنا"), ("#process", "آلية العمل"), ("#why", "لماذا نحن"), ("#contact", "تواصل معنا")],
    eyebrow="شركة سعودية مسجّلة لدى وزارة التجارة",
    h1='من الهدم حتى التسليم النهائي… <span>شريك واحد</span> لدورة مشروعك كاملة',
    hero_p="نجمع تحت سقف واحد فرق الهدم والحفر والإنشاءات والتشطيبات، لتتعامل مع جهة واحدة مسؤولة عن الجودة والجدول الزمني والتكلفة.",
    cta1="احجز معاينة لموقعك", cta2="اكتشف خدماتنا",
    meta=[("منذ", "1436هـ"), ("نعمل في", "الرياض · المدينة المنورة"), ("سجل تجاري", CR)],
    about_eb="من نحن", about_h="مقاول واحد لمشروعك… من الأرض حتى المفتاح",
    about_p="شركة ساحل البحر الأحمر للمقاولات العامة شركة سعودية مسجّلة لدى وزارة التجارة، تقدّم حلول مقاولات متكاملة تغطي دورة المشروع من إزالة المبنى القديم حتى تسليم المبنى الجديد جاهزاً للاستخدام. نجمع تحت سقف واحد فرق الهدم والحفر والإنشاءات والتشطيبات، ليتعامل عملاؤنا من ملاك العقار والمطورين وأصحاب المشاريع التجارية مع جهة واحدة مسؤولة عن الجودة والجدول الزمني والتكلفة.",
    stats=[("12", "عاماً من الخبرة منذ 1436هـ"), ("4", "خدمات متكاملة تغطي دورة المشروع"), ("2", "مدينتان: الرياض والمدينة المنورة"), ("1", "جهة واحدة مسؤولة حتى التسليم")],
    vm_eb="الرؤية والرسالة", vm_h="نبني على أساسٍ من الثقة", vm_p="ما نطمح إليه، وما نلتزم به في كل مشروع.",
    vm=[("رؤيتنا", "أن نكون الخيار الأول لملاك العقار والمطورين في المملكة لتنفيذ المشاريع الإنشائية المتكاملة، بجودة تظهر في كل تفصيل وثقة تمتد إلى ما بعد التسليم."),
        ("رسالتنا", "تقديم خدمات مقاولات متكاملة من الهدم حتى التسليم، بإدارة احترافية وكوادر مؤهلة ومعدات حديثة، مع الالتزام بالمخططات المعتمدة ومعايير السلامة والجدول الزمني المتفق عليه.")],
    val_eb="قيمنا", val_h="قيم نلتزم بها في كل موقع",
    values=[("الجودة أولاً", "نلتزم بالمواصفات والمخططات المعتمدة، ونفحص كل مرحلة قبل الانتقال لما بعدها."),
            ("السلامة", "نطبّق اشتراطات السلامة المهنية لحماية فريقنا والجيران والممتلكات."),
            ("الالتزام بالمواعيد", "جدول زمني واضح منذ اليوم الأول، ومتابعة دورية لنسب الإنجاز."),
            ("الشفافية", "تسعير واضح بالبنود، وتقارير دورية، وتواصل مباشر مع العميل."),
            ("الاحترافية", "كوادر هندسية وفنية مؤهلة، وإدارة منظمة للموقع والموارد."),
            ("المسؤولية", "نتحمّل مسؤولية المشروع كاملاً من استلام الموقع حتى التسليم.")],
    svc_eb="خدماتنا", svc_h="أربع خدمات… دورة مشروع واحدة",
    svc_p="نستلم الموقع كما هو، ونسلّمه مبنىً جاهزاً للاستخدام، عبر أربع مراحل متصلة ينفذها فريق واحد.",
    perks_label="مزايا العمل معنا",
    services=[
        ("الهدم", "الهدم والإزالة", "إزالة المباني والمنشآت القديمة بأمان، وترحيل المخلّفات وفق معايير السلامة، وتسليم الأرض جاهزة للمرحلة التالية.",
         [("المعاينة وخطة الهدم", "دراسة المبنى وتحديد أسلوب الهدم الآمن."), ("تأمين الموقع", "فصل الخدمات وتسوير الموقع وحماية المجاور."), ("الهدم الكلي والجزئي", "مبانٍ سكنية وتجارية وأسوار وملاحق."), ("ترحيل المخلّفات", "تحميل المخلّفات ونقلها إلى المرادم المعتمدة.")],
         ["التزام بأنظمة الجهات المختصة", "أرض نظيفة ومسوّاة", "حماية المباني المجاورة", "معدات حديثة وطاقم مدرّب"]),
        ("الحفر", "الحفر والردم وتجهيز الموقع", "أعمال حفر وردم وتسوية دقيقة وفق المناسيب والمخططات المعتمدة، لتأسيس صحيح يبدأ من الأرض.",
         [("حفر الأساسات", "حفر القواعد والأساسات والأقبية بالأبعاد المطلوبة."), ("الردم والدكّ", "ردم على طبقات ودكّ وفق المواصفات."), ("التسوية والمناسيب", "تسوية الموقع ومطابقة المناسيب للمخططات."), ("ترحيل ناتج الحفر", "إزالة الصخور والتربة غير الصالحة ونقلها.")],
         ["جاهزية سريعة لبدء الإنشاء", "حماية جوانب الحفر", "معدات تناسب طبيعة كل تربة", "دقة في المناسيب والأبعاد"]),
        ("إنشاءات العظم", "إنشاءات العظم", "تنفيذ الهيكل الخرساني والإنشائي وفق المخططات الهندسية المعتمدة، أساس متين لعمر المبنى وسلامته.",
         [("الأساسات والميدات", "القواعد والميدات وفق التصميم الإنشائي."), ("الهيكل الخرساني", "الأعمدة والجسور والأسقف الخرسانية."), ("النجارة والحديد", "النجارة المسلّحة وتركيب حديد التسليح."), ("البلوك والعزل", "أعمال البلوك وعزل الأساسات والأسطح.")],
         ["جدول تنفيذ واضح", "مواد بمواصفات معتمدة", "إشراف هندسي على كل صبّة", "تنفيذ مطابق للمخططات"]),
        ("التشطيبات النهائية", "التشطيبات النهائية", "أعمال تشطيب متكاملة تحوّل الهيكل إلى مبنى جاهز للاستخدام، وتسليم نهائي «مفتاح باليد».",
         [("اللياسة والدهانات", "لياسة ودهانات وديكورات بجودة عالية."), ("الأرضيات والرخام", "بلاط وأرضيات ورخام بتنفيذ دقيق."), ("الكهرباء والسباكة", "التمديدات الكهربائية والسباكة والتكييف."), ("الجبس والواجهات", "أسقف معلّقة وأبواب ونوافذ وواجهات.")],
         ["تسليم جاهز للسكن أو التشغيل", "عناية بأدق التفاصيل", "مواد تناسب الميزانية والذوق", "تشطيب كامل من جهة واحدة"]),
    ],
    flow=("استلام الموقع كما هو", "تسليم المبنى جاهزاً"),
    pr_eb="آلية العمل", pr_h="من المعاينة إلى التسليم في ست خطوات",
    process=[("المعاينة والاستشارة", "زيارة الموقع ودراسة احتياج العميل والمخططات."), ("العرض والتسعير", "عرض فني ومالي واضح بالبنود ومدة التنفيذ."), ("التعاقد والتخطيط", "توقيع العقد واعتماد الجدول الزمني وخطة التنفيذ."),
             ("التنفيذ", "تنفيذ المراحل وفق المخططات ومعايير السلامة."), ("المتابعة والجودة", "تقارير دورية وفحص كل مرحلة قبل الانتقال لما بعدها."), ("التسليم النهائي", "فحص شامل وتسليم المشروع جاهزاً للعميل.")],
    why_eb="لماذا نحن", why_h="لماذا تختار ساحل البحر الأحمر؟", why_p="أربعة أسباب تجعلنا شريكك الأنسب من البداية حتى التسليم.",
    why=[("جهة واحدة لكامل المشروع", "فريق واحد من الهدم حتى التسليم، بلا تعدد مقاولين ولا تضارب في المسؤوليات."), ("شركة موثّقة رسمياً", f"مسجّلة لدى وزارة التجارة بسجل تجاري رقم {CR}."),
         ("خبرة 12 عاماً", "خبرة عملية في تنفيذ مشاريع سكنية وتجارية بمختلف الأحجام."), ("السلامة والجودة معاً", "معايير سلامة صارمة في الموقع، وفحص جودة في كل مرحلة.")],
    cl_eb="عملاؤنا", cl_h="لمن نعمل", cl_p="حلول مصمّمة لثلاث فئات رئيسية من العملاء.",
    clients=[("ملاك العقار", "من هدم المنزل القديم حتى استلام مفتاح بيتك الجديد، نتولى كل شيء بعقد واحد."), ("المطورون العقاريون", "تنفيذ مشاريع سكنية بجداول زمنية منضبطة وجودة تحفظ قيمة الاستثمار."), ("المشاريع التجارية", "محلات ومبانٍ ومنشآت تجارية تُسلَّم جاهزة للتشغيل في الموعد المتفق عليه.")],
    ct_eb="تواصل معنا", ct_h="لنبدأ مشروعك القادم معاً", ct_p="احجز معاينة لموقعك، واستلم عرضاً فنياً ومالياً واضحاً.",
    c_labels=("رقم الجوال", "البريد الإلكتروني", "مناطق العمل", "رقم السجل التجاري"), cr_short="س.ت", copy="نسخ", copied="تم النسخ", call="اتصال", mail="إرسال بريد", verified="منشأة مسجّلة لدى وزارة التجارة — السجل التجاري", ftxt="مقاولات عامة متكاملة من الهدم حتى التسليم النهائي في الرياض والمدينة المنورة.", areas=CT["areas_ar"],
    wa_text="السلام عليكم، أرغب في حجز معاينة لموقع مشروعي",
    dl_ar="تحميل البروفايل (عربي)", dl_en="Company Profile (EN)",
    rights="جميع الحقوق محفوظة", legal=CO["legal_ar"],
    locale="ar_SA", menu="القائمة", wa_label="تواصل عبر واتساب",
)

EN = dict(
    lang="en", dir="ltr", path="/en/", other="/", other_label="عربي",
    title="Sahel Red Sea General Contracting | From Demolition to Handover",
    desc="Saudi general contractor in Riyadh and Madinah: demolition, excavation, structural works and final finishing under one contract. Experience since 1436 AH.",
    name=CO["name_en"], sub=CO["sub_en"],
    nav=[("#about", "About"), ("#services", "Services"), ("#process", "Process"), ("#why", "Why Us"), ("#contact", "Contact")],
    eyebrow="Registered with the Saudi Ministry of Commerce",
    h1='From demolition to final handover — <span>one partner</span> for your entire project',
    hero_p="Demolition, excavation, structural and finishing teams under one roof, so you deal with a single party responsible for quality, schedule and cost.",
    cta1="Book a Site Survey", cta2="Explore Our Services",
    meta=[("Since", "1436 AH"), ("Serving", "Riyadh · Madinah"), ("C.R.", CR)],
    about_eb="About Us", about_h="One contractor for your project — from ground to keys",
    about_p="Sahel Red Sea General Contracting is a Saudi company registered with the Ministry of Commerce, delivering integrated contracting solutions that cover the entire project cycle — from removing the old building to handing over the new one ready for use. We bring demolition, excavation, structural and finishing teams under one roof, so property owners, developers and commercial clients deal with a single party responsible for quality, schedule and cost.",
    stats=[("12", "Years of experience since 1436 AH"), ("4", "Integrated services covering the full cycle"), ("2", "Cities: Riyadh and Madinah"), ("1", "Single point of accountability")],
    vm_eb="Vision & Mission", vm_h="Building on a foundation of trust", vm_p="What we aspire to, and what we commit to on every project.",
    vm=[("Our Vision", "To be the first choice for property owners and developers in the Kingdom for integrated construction projects — with quality that shows in every detail and trust that extends beyond handover."),
        ("Our Mission", "To deliver integrated contracting services from demolition to handover through professional management, qualified staff and modern equipment, adhering to approved drawings, safety standards and the agreed schedule.")],
    val_eb="Our Values", val_h="Values we uphold on every site",
    values=[("Quality First", "We adhere to approved specifications and drawings, and inspect every stage before moving on."),
            ("Safety", "We apply occupational safety requirements to protect our team, neighbors and property."),
            ("On-Time Delivery", "A clear schedule from day one, with regular progress tracking."),
            ("Transparency", "Clear itemized pricing, regular reports and direct communication."),
            ("Professionalism", "Qualified engineering and technical staff with organized site management."),
            ("Accountability", "Full responsibility for the project, from site handover to final delivery.")],
    svc_eb="Our Services", svc_h="Four services — one project cycle",
    svc_p="We take the site as it is and hand it back as a ready-to-use building, through four connected phases delivered by one team.",
    perks_label="Why work with us",
    services=[
        ("Demolition", "Demolition & Removal", "Safe removal of old buildings and structures, debris hauling to safety standards, and land handed over ready for the next phase.",
         [("Survey & Demolition Plan", "Assessing the building and defining the safe method."), ("Site Securing", "Disconnecting utilities, fencing and protecting neighbors."), ("Full & Partial Demolition", "Residential and commercial buildings, walls and annexes."), ("Debris Removal", "Loading and transporting debris to approved landfills.")],
         ["Compliance with authority regulations", "Clean, leveled land", "Protection of adjacent buildings", "Modern equipment & trained crew"]),
        ("Excavation", "Excavation & Site Preparation", "Precise excavation, backfilling and leveling to approved levels and drawings — a sound foundation starts from the ground.",
         [("Foundation Excavation", "Footings, foundations and basements to required dimensions."), ("Backfill & Compaction", "Layered backfilling and compaction to specification."), ("Grading & Levels", "Leveling the site and matching levels to drawings."), ("Spoil Removal", "Removing and hauling rock and unsuitable soil.")],
         ["Fast readiness for construction", "Excavation side protection", "Equipment for every soil type", "Accurate levels and dimensions"]),
        ("Structural Works", "Structural Works", "The concrete and structural frame built to approved engineering drawings — a solid base for the building's life and safety.",
         [("Foundations & Grade Beams", "Footings and grade beams per the structural design."), ("Concrete Frame", "Concrete columns, beams and slabs."), ("Formwork & Rebar", "Formwork and reinforcement steel installation."), ("Blockwork & Insulation", "Blockwork and waterproofing of foundations and roofs.")],
         ["Clear execution schedule", "Materials to approved specifications", "Engineering supervision on every pour", "Execution true to drawings"]),
        ("Final Finishing", "Final Finishing", "Integrated finishing that turns the structure into a ready-to-use building, with a final turnkey handover.",
         [("Plastering & Painting", "High-quality plastering, painting and decor."), ("Flooring & Marble", "Tiles, flooring and marble with precise execution."), ("Electrical & Plumbing", "Electrical wiring, plumbing and air conditioning."), ("Gypsum & Facades", "Suspended ceilings, doors, windows and facades.")],
         ["Ready for living or operation", "Attention to the finest details", "Materials to suit budget and taste", "Complete finishing from one party"]),
    ],
    flow=("Site taken as it is", "Building handed over ready"),
    pr_eb="How We Work", pr_h="From site visit to handover in six steps",
    process=[("Survey & Consultation", "Site visit and study of your needs and drawings."), ("Proposal & Pricing", "A clear, itemized technical and financial proposal with timeline."), ("Contract & Planning", "Signing the contract and approving the schedule and plan."),
             ("Execution", "Delivering each phase to drawings and safety standards."), ("Monitoring & Quality", "Regular reports and inspection of every stage."), ("Final Handover", "Comprehensive inspection and handover of the finished project.")],
    why_eb="Why Us", why_h="Why choose Sahel Red Sea?", why_p="Four reasons we're your ideal partner from start to handover.",
    why=[("One Party for the Whole Project", "One team from demolition to handover — no multiple contractors, no conflicting responsibilities."), ("Officially Registered", f"Registered with the Ministry of Commerce, C.R. No. {CR}."),
         ("12 Years of Experience", "Hands-on delivery of residential and commercial projects of all sizes."), ("Safety and Quality Together", "Strict on-site safety standards and quality inspection at every stage.")],
    cl_eb="Our Clients", cl_h="Who we work for", cl_p="Solutions designed for three main client groups.",
    clients=[("Property Owners", "From demolishing your old house to receiving the keys to your new one — all under one contract."), ("Real Estate Developers", "Residential projects on disciplined schedules, with quality that protects your investment."), ("Commercial Projects", "Shops, buildings and facilities handed over ready for operation on the agreed date.")],
    ct_eb="Contact Us", ct_h="Let's start your next project together", ct_p="Book a site survey and receive a clear technical and financial proposal.",
    c_labels=("Mobile Number", "Email Address", "Service Areas", "Commercial Registration No."), cr_short="C.R.", copy="Copy", copied="Copied", call="Call", mail="Send email", verified="Registered with the Ministry of Commerce — C.R.", ftxt="Integrated general contracting from demolition to final handover in Riyadh and Madinah.", areas=CT["areas_en"],
    wa_text="Hello, I'd like to book a site survey for my project",
    dl_ar="الملف التعريفي (عربي)", dl_en="Download Profile (EN)",
    rights="All rights reserved", legal=CO["legal_en"],
    locale="en_US", menu="Menu", wa_label="Chat on WhatsApp",
)

IC = {
 "phone": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg>',
 "mail": '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>',
 "cr": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/></svg>',
 "pin": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg>',
 "copy": '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/></svg>',
 "go": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M8 7h9v9"/></svg>',
 "check": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/></svg>',
}

def field(ic, label, val, href=None, act_label="", copy_label="", cls=""):
    acts = f'<button class="icon-btn" type="button" data-copy="{val}" aria-label="{copy_label}: {label}" title="{copy_label}">{IC["copy"]}</button>' if copy_label else ""
    if href:
        acts = f'<a class="icon-btn" href="{href}" aria-label="{act_label}" title="{act_label}">{IC["go"]}</a>' + acts
    v = f'<span class="val {cls}">{val}</span>' if cls else f'<span class="val ltr">{val}</span>'
    return f'<div class="field"><div class="field-ic">{IC[ic]}</div><div><small>{label}</small>{v}</div><div class="field-act">{acts}</div></div>'

def topbar_items(L, footer=False):
    lb = L["c_labels"]
    return (f'<a class="tb-item" href="tel:+{PHONE_INTL}">{IC["phone"]}<span class="ltr">{PHONE}</span></a>'
            f'<a class="tb-item" href="mailto:{EMAIL}">{IC["mail"]}<span class="ltr">{EMAIL}</span></a>'
            f'<span class="tb-item">{IC["cr"]}<span>{L["cr_short"]} <b class="ltr">{CR}</b></span></span>')

def n2(i): return f"{i+1:02d}"
def cards(items, cls="g3"):
    return f'<div class="grid {cls}">' + "".join(f'<article class="card reveal"><div class="num">{n2(i)}</div><h3>{t}</h3><p>{d}</p></article>' for i, (t, d) in enumerate(items)) + '</div>'
def head(eb, h, p=None):
    return f'<div class="head reveal"><div class="eyebrow">{eb}</div><h2>{h}</h2>' + (f'<p>{p}</p>' if p else '') + '</div>'

def render(L):
    from urllib.parse import quote
    pre = "../" if L["lang"] == "en" else ""
    wa = f"https://wa.me/{WA_INTL}?text={quote(L['wa_text'])}"
    tabs = "".join(f'<button class="svc-tab{" on" if i==0 else ""}" role="tab" aria-selected="{"true" if i==0 else "false"}" data-i="{i}"><span class="num">{n2(i)}</span><strong>{s[0]}</strong></button>' for i, s in enumerate(L["services"]))
    panels = "".join(
        f'<div class="svc-panel{" on" if i==0 else ""}" role="tabpanel" data-i="{i}"><h3>{s[1]}</h3><p>{s[2]}</p><div class="steps">' +
        "".join(f'<div class="step"><div class="num">{n2(j)}</div><h4>{t}</h4><p>{d}</p></div>' for j, (t, d) in enumerate(s[3])) +
        f'</div><div class="eyebrow" style="margin-bottom:14px">{L["perks_label"]}</div><div class="perks">' + "".join(f'<span>{p}</span>' for p in s[4]) + '</div></div>'
        for i, s in enumerate(L["services"]))
    arrow = "←" if L["dir"] == "rtl" else "→"
    ldl = L["c_labels"]
    alt_lang = "en" if L["lang"] == "ar" else "ar"
    ld = {"@context": "https://schema.org", "@type": "GeneralContractor", "name": L["legal"], "alternateName": CO["name_en"], "identifier": {"@type": "PropertyValue", "propertyID": "CR", "value": CR}, "url": DOMAIN + L["path"],
          "telephone": "+" + PHONE_INTL, "email": EMAIL, "logo": DOMAIN + "/assets/logo.svg", "image": DOMAIN + "/assets/og.png",
          "areaServed": ["Riyadh", "Madinah"], "address": {"@type": "PostalAddress", "addressCountry": "SA", "addressLocality": "Riyadh"}}
    import json
    return f'''<!doctype html>
<html lang="{L["lang"]}" dir="{L["dir"]}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{L["title"]}</title>
<meta name="description" content="{L["desc"]}">
<meta name="theme-color" content="#161412">
<link rel="canonical" href="{DOMAIN}{L["path"]}">
<link rel="alternate" hreflang="{L["lang"]}" href="{DOMAIN}{L["path"]}">
<link rel="alternate" hreflang="{alt_lang}" href="{DOMAIN}{L["other"]}">
<link rel="alternate" hreflang="x-default" href="{DOMAIN}/">
<meta property="og:type" content="website">
<meta property="og:title" content="{L["title"]}">
<meta property="og:description" content="{L["desc"]}">
<meta property="og:url" content="{DOMAIN}{L["path"]}">
<meta property="og:image" content="{DOMAIN}/assets/og.png">
<meta property="og:locale" content="{L["locale"]}">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&family=Inter:wght@400;500;600&family=Lora:wght@500;600&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/tokens.css">
<link rel="stylesheet" href="/assets/style.css">
<script type="application/ld+json">{json.dumps(ld, ensure_ascii=False)}</script>
</head>
<body>
<div class="topbar" id="top"><div class="wrap"><div class="tb-items">{topbar_items(L)}</div><span class="tb-item tb-hide-m">{IC["pin"]}{L["areas"]}</span></div></div>
<header><div class="wrap hbar">
<a class="brand" href="{L["path"]}">{logo("lg-h")}<div><div class="brand-name">{L["name"]}</div><div class="brand-sub">{L["sub"]}</div></div></a>
<button class="menu-btn" aria-label="{L["menu"]}" aria-expanded="false">{MENU}</button>
<nav>{"".join(f'<a href="{h}">{t}</a>' for h, t in L["nav"])}<a class="lang" href="{L["other"]}" hreflang="{alt_lang}">{L["other_label"]}</a></nav>
</div></header>

<main>
<section class="hero"><div class="wrap">
{logo("lg-m", "hero-mark")}
<div class="hero-grid">
<div><div class="eyebrow">{L["eyebrow"]}</div><h1>{L["h1"]}</h1><p>{L["hero_p"]}</p>
<div class="hero-cta"><a class="btn btn-gold" href="{wa}" target="_blank" rel="noopener">{L["cta1"]}</a><a class="btn btn-ghost" href="#services">{L["cta2"]}</a></div>
<div class="hero-meta">{"".join(f'<div><b>{a}</b>{b}</div>' for a, b in L["meta"])}</div></div>
{logo("lg-x", "hero-logo")}
</div></div></section>

<section id="about"><div class="wrap about">
<div class="reveal"><div class="head" style="margin-bottom:24px"><div class="eyebrow">{L["about_eb"]}</div><h2>{L["about_h"]}</h2></div><p class="lead">{L["about_p"]}</p></div>
<div class="stats reveal">{"".join(f'<div class="stat"><b>{a}</b><span>{b}</span></div>' for a, b in L["stats"])}</div>
</div></section>

<section class="alt"><div class="wrap">{head(L["vm_eb"], L["vm_h"], L["vm_p"])}{cards(L["vm"], "g2")}</div></section>

<section><div class="wrap">{head(L["val_eb"], L["val_h"])}{cards(L["values"], "g3")}</div></section>

<section id="services" class="alt"><div class="wrap">{head(L["svc_eb"], L["svc_h"], L["svc_p"])}
<div class="reveal"><div class="svc" role="tablist">{tabs}</div>{panels}
<div class="flow"><span>{L["flow"][0]}</span><span>{arrow} {arrow} {arrow}</span><span>{L["flow"][1]}</span></div></div>
</div></section>

<section id="process"><div class="wrap">{head(L["pr_eb"], L["pr_h"])}{cards(L["process"], "g3")}</div></section>

<section id="why" class="dark"><div class="wrap">{head(L["why_eb"], L["why_h"], L["why_p"])}{cards(L["why"], "g2")}</div></section>

<section class="alt"><div class="wrap">{head(L["cl_eb"], L["cl_h"], L["cl_p"])}{cards(L["clients"], "g3")}</div></section>

<section id="contact"><div class="wrap contact">
<div class="reveal"><div class="head" style="margin-bottom:0"><div class="eyebrow">{L["ct_eb"]}</div><h2>{L["ct_h"]}</h2><p>{L["ct_p"]}</p></div>
<div class="verified">{IC["check"]}<span>{L["verified"]} <b class="ltr">{CR}</b></span></div>
<div class="dl"><a class="btn btn-gold" href="{wa}" target="_blank" rel="noopener">{L["cta1"]}</a><a class="btn btn-dark" href="/assets/sahel-profile-ar.pdf" download>{L["dl_ar"]}</a><a class="btn btn-line" href="/assets/sahel-profile-en.pdf" download>{L["dl_en"]}</a></div></div>
<div class="fields reveal">
{field("phone", ldl[0], PHONE, f"tel:+{PHONE_INTL}", L["call"], L["copy"])}
{field("mail", ldl[1], EMAIL, f"mailto:{EMAIL}", L["mail"], L["copy"])}
{field("cr", ldl[3], CR, None, "", L["copy"])}
{field("pin", ldl[2], L["areas"], cls="rtl")}
</div></div></section>
</main>

<footer><div class="wrap">
<div class="fmain">
<div><a class="brand" href="#top">{logo("lg-f")}<div><div class="brand-name">{L["name"]}</div><div class="brand-sub">{L["sub"]}</div></div></a><p class="fdesc">{L["ftxt"]}</p></div>
<div class="fcontact">{topbar_items(L, footer=True)}<span class="tb-item">{IC["pin"]}{L["areas"]}</span></div>
</div>
<div class="fbottom"><span>© <span id="yr">2026</span> {L["legal"]} — {L["rights"]}</span><span>{L["cr_short"]} <span class="ltr">{CR}</span></span></div>
</div></footer>
<div class="toast" role="status" aria-live="polite" data-ok="{L["copied"]}"></div>

<a class="wa" href="{wa}" target="_blank" rel="noopener" aria-label="{L["wa_label"]}">{WA}</a>
<script src="/assets/main.js" defer></script>
</body>
</html>'''

write_tokens()
open(os.path.join(ROOT, "index.html"), "w").write(render(AR))
open(os.path.join(ROOT, "en", "index.html"), "w").write(render(EN))
print("ok")
